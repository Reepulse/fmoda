<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{px_sidespecials}prestashop>px_sidespecials_1276c482cb32edf4fce51761a9792716'] = 'منتجات خاصة';
$_MODULE['<{px_sidespecials}prestashop>px_sidespecials_f95ceb82c51c99dc9b9e5678b291c44b'] = 'بيع جميع المنتجات';
