<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{px_sidebestsellers}prestashop>px_sidebestsellers_d7b2933ba512ada478c97fa43dd7ebe6'] = 'أفضل الكتب مبيعا';
$_MODULE['<{px_sidebestsellers}prestashop>px_sidebestsellers_eae99cd6a931f3553123420b16383812'] = 'جميع الكتب مبيعا';
